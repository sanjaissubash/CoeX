"""
Legacy prediction/world-cup app placeholder.

This package was replaced by `legacy_app/` to focus QA and development on
ProductOS (`backend/`). Importing `app` will raise an informative error.
"""

raise ImportError(
    "Legacy 'app' package has been moved to 'legacy_app/'.\n"
    "If you need to run the legacy code, import from 'legacy_app' instead."
)
