from datetime import datetime
from .db import db

# --- Minimal football models (legacy app compatibility) ---
class Match(db.Model):
    __tablename__ = "matches"

    id = db.Column(db.Integer, primary_key=True)
    team_a = db.Column(db.String(100), nullable=False)
    team_b = db.Column(db.String(100), nullable=False)
    stage = db.Column(db.String(100), nullable=True)
    venue = db.Column(db.String(200), nullable=True)
    kickoff_time = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    is_locked = db.Column(db.Boolean, default=False, nullable=False)
    winner = db.Column(db.String(100), nullable=True)
    potm_winner = db.Column(db.String(200), nullable=True)
    api_match_id = db.Column(db.String(100), nullable=True)


class Prediction(db.Model):
    __tablename__ = "predictions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    match_id = db.Column(db.Integer, db.ForeignKey("matches.id"), nullable=False)
    prediction = db.Column(db.String(100), nullable=True)
    potm_prediction = db.Column(db.String(200), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


# ============ WORKSPACE LAYER ============
class Workspace(db.Model):
    __tablename__ = "workspaces"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    families = db.relationship("Family", backref="workspace", lazy=True, cascade="all, delete-orphan")
    products = db.relationship("Product", backref="workspace", lazy=True, cascade="all, delete-orphan")
    activities = db.relationship("Activity", backref="workspace", lazy=True, cascade="all, delete-orphan")
    global_notes = db.relationship("GlobalNote", backref="workspace", lazy=True, cascade="all, delete-orphan")


# ============ FAMILY LAYER ============
class Family(db.Model):
    __tablename__ = "families"

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspaces.id"), nullable=False)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=True)
    icon = db.Column(db.String(50), default="folder", nullable=False)
    color = db.Column(db.String(7), default="#6366f1", nullable=False)
    display_order = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    products = db.relationship("Product", backref="family", lazy=True, cascade="all, delete-orphan")

    __table_args__ = (db.UniqueConstraint("workspace_id", "name", name="uq_workspace_family_name"),)


# ============ PRODUCT TEMPLATES ============
class ProductTemplate(db.Model):
    __tablename__ = "product_templates"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    icon = db.Column(db.String(50), default="box", nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    # These will be used when creating products from template
    default_milestones = db.Column(db.JSON, nullable=True)  # List of milestone names
    default_tasks = db.Column(db.JSON, nullable=True)  # List of task names
    default_context_blocks = db.Column(db.JSON, nullable=True)  # List of context block titles


# ============ PRODUCT LAYER ============
class Product(db.Model):
    __tablename__ = "products"

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspaces.id"), nullable=False)
    family_id = db.Column(db.Integer, db.ForeignKey("families.id"), nullable=False)
    template_id = db.Column(db.Integer, db.ForeignKey("product_templates.id"), nullable=True)
    owner_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    name = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    icon = db.Column(db.String(50), default="box", nullable=False)

    # Lifecycle: IDEA, RESEARCH, PLANNING, CREATING, TESTING, READY_TO_SELL, PUBLISHED, OPTIMIZING, ARCHIVED
    lifecycle = db.Column(db.String(50), default="IDEA", nullable=False)
    
    # Status: ACTIVE, PAUSED, BLOCKED, COMPLETED, ARCHIVED
    status = db.Column(db.String(50), default="ACTIVE", nullable=False)

    # Progress tracking for each lifecycle stage
    progress_data = db.Column(db.JSON, nullable=True)  # {IDEA: completed, RESEARCH: in_progress, ...}

    # Product metadata
    target_audience = db.Column(db.Text, nullable=True)
    key_features = db.Column(db.JSON, nullable=True)  # List of features
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    context_blocks = db.relationship("ContextBlock", backref="product", lazy=True, cascade="all, delete-orphan")
    sessions = db.relationship("Session", backref="product", lazy=True, cascade="all, delete-orphan")
    decisions = db.relationship("Decision", backref="product", lazy=True, cascade="all, delete-orphan")
    milestones = db.relationship("Milestone", backref="product", lazy=True, cascade="all, delete-orphan")
    tasks = db.relationship("Task", backref="product", lazy=True, cascade="all, delete-orphan")
    prompts = db.relationship("Prompt", backref="product", lazy=True, cascade="all, delete-orphan")
    product_notes = db.relationship("ProductNote", backref="product", lazy=True, cascade="all, delete-orphan")
    product_knowledge = db.relationship("ProductKnowledge", backref="product", lazy=True, cascade="all, delete-orphan")
    assets = db.relationship("Asset", backref="product", lazy=True, cascade="all, delete-orphan")
    versions = db.relationship("Version", backref="product", lazy=True, cascade="all, delete-orphan")
    links = db.relationship("Link", backref="product", lazy=True, cascade="all, delete-orphan")
    marketing = db.relationship("Marketing", backref="product", lazy=True, cascade="all, delete-orphan")
    research = db.relationship("Research", backref="product", lazy=True, cascade="all, delete-orphan")

    __table_args__ = (db.UniqueConstraint("workspace_id", "slug", name="uq_workspace_product_slug"),)


# ============ PRODUCT PLANNING ============
class Milestone(db.Model):
    __tablename__ = "milestones"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    priority = db.Column(db.String(50), default="MEDIUM", nullable=False)  # HIGH, MEDIUM, LOW
    status = db.Column(db.String(50), default="NOT_STARTED", nullable=False)  # NOT_STARTED, IN_PROGRESS, COMPLETED
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    tasks = db.relationship("Task", backref="milestone", lazy=True, cascade="all, delete-orphan")


class Task(db.Model):
    __tablename__ = "tasks"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    milestone_id = db.Column(db.Integer, db.ForeignKey("milestones.id"), nullable=True)
    
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    priority = db.Column(db.String(50), default="MEDIUM", nullable=False)  # HIGH, MEDIUM, LOW
    status = db.Column(db.String(50), default="NOT_STARTED", nullable=False)  # NOT_STARTED, IN_PROGRESS, COMPLETED
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    completed_at = db.Column(db.DateTime, nullable=True)


# ============ PRODUCT KNOWLEDGE ============
class ContextBlock(db.Model):
    __tablename__ = "context_blocks"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), default="OTHER", nullable=False)  # OVERVIEW, TECHNOLOGY, AUDIENCE, FEATURES, CONSTRAINTS, OTHER
    priority = db.Column(db.Integer, default=1, nullable=False)
    is_public = db.Column(db.Boolean, default=True, nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class Session(db.Model):
    __tablename__ = "sessions"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    tool = db.Column(db.String(50), default="MANUAL", nullable=False)  # ChatGPT, Claude, Gemini, Manual, Other
    goal = db.Column(db.Text, nullable=False)
    summary = db.Column(db.Text, nullable=False)
    outcome = db.Column(db.Text, nullable=True)
    next_steps = db.Column(db.Text, nullable=True)
    full_output = db.Column(db.Text, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class Decision(db.Model):
    __tablename__ = "decisions"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    decision = db.Column(db.Text, nullable=False)
    rationale = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(50), default="ACTIVE", nullable=False)  # ACTIVE, SUPERSEDED, ARCHIVED
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class ProductNote(db.Model):
    __tablename__ = "product_notes"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    pinned = db.Column(db.Boolean, default=False, nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class ProductKnowledge(db.Model):
    __tablename__ = "product_knowledge"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), default="OTHER", nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class Prompt(db.Model):
    __tablename__ = "prompts"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    use_case = db.Column(db.String(200), nullable=True)
    ai_tool = db.Column(db.String(50), nullable=True)  # ChatGPT, Claude, Gemini, etc
    tags = db.Column(db.JSON, nullable=True)  # List of tags
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


# ============ PRODUCT ASSETS & FILES ============
class Asset(db.Model):
    __tablename__ = "assets"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    name = db.Column(db.String(200), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)  # Relative path in storage/products/
    file_type = db.Column(db.String(50), nullable=False)  # image, document, spreadsheet, video, etc
    size_bytes = db.Column(db.Integer, nullable=True)
    description = db.Column(db.Text, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class Version(db.Model):
    __tablename__ = "versions"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    version_number = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=True)
    release_date = db.Column(db.DateTime, nullable=True)
    changes = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(50), default="DRAFT", nullable=False)  # DRAFT, RELEASED, ARCHIVED
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class Link(db.Model):
    __tablename__ = "links"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    url = db.Column(db.String(500), nullable=False)
    category = db.Column(db.String(50), nullable=True)  # DEMO, REPO, DOCUMENTATION, EXTERNAL, etc
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


# ============ PRODUCT SELLING ============
class Marketing(db.Model):
    __tablename__ = "marketing"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    channel = db.Column(db.String(50), nullable=False)  # WEBSITE, ETSY, APPSTORE, SOCIAL, EMAIL, etc
    title = db.Column(db.String(200), nullable=True)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=True)
    status = db.Column(db.String(50), default="DRAFT", nullable=False)  # DRAFT, PUBLISHED, ARCHIVED
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class Research(db.Model):
    __tablename__ = "research"

    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    source = db.Column(db.String(200), nullable=True)
    category = db.Column(db.String(50), default="OTHER", nullable=False)  # MARKET, COMPETITOR, USER, TECHNICAL, OTHER
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


# ============ GLOBAL NOTES ============
class GlobalNote(db.Model):
    __tablename__ = "global_notes"

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspaces.id"), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    pinned = db.Column(db.Boolean, default=False, nullable=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


# ============ ACTIVITY TRACKING ============
class Activity(db.Model):
    __tablename__ = "activities"

    id = db.Column(db.Integer, primary_key=True)
    workspace_id = db.Column(db.Integer, db.ForeignKey("workspaces.id"), nullable=False)
    
    action = db.Column(db.String(100), nullable=False)  # CREATED, UPDATED, DELETED, COMPLETED, etc
    entity_type = db.Column(db.String(50), nullable=False)  # PRODUCT, TASK, MILESTONE, SESSION, etc
    entity_id = db.Column(db.Integer, nullable=False)
    entity_name = db.Column(db.String(200), nullable=True)
    details = db.Column(db.JSON, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


# ============ USER (MINIMAL FOR NOW) ============
class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    products = db.relationship("Product", backref="owner", lazy=True)
