"""
Legacy productos API stub. The legacy endpoints were moved to `legacy_app/`.
Importing this module will raise an informative error.
"""

raise ImportError("Legacy productos API moved to 'legacy_app'. Import from legacy_app.productos_api if needed.")

# ---- Families ----
@productos_bp.get("/families")
def list_families():
    """List all families in default workspace."""
    workspace = get_default_workspace()
    families = Family.query.filter_by(workspace_id=workspace.id).order_by(Family.display_order).all()
    return jsonify({
        "families": [
            {
                "id": f.id,
                "name": f.name,
                "description": f.description,
                "color": f.color,
                "icon": f.icon,
                "product_count": len(f.products),
                "created_at": f.created_at.isoformat(),
                "updated_at": f.updated_at.isoformat(),
            } for f in families
        ]
    })

@productos_bp.post("/families")
def create_family():
    """Create a new family."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"ok": False, "message": "Family name is required."}), 400
    
    if Family.query.filter_by(workspace_id=workspace.id, name=name).first():
        return jsonify({"ok": False, "message": "Family already exists."}), 409
    
    family = Family(
        workspace_id=workspace.id,
        name=name,
        description=data.get("description", ""),
        color=data.get("color", "#6366f1"),
        icon=data.get("icon", "folder")
    )
    db.session.add(family)
    db.session.commit()
    
    log_activity(workspace.id, "CREATED", "FAMILY", family.id, family.name)
    
    return jsonify({
        "ok": True,
        "family": {
            "id": family.id,
            "name": family.name,
            "description": family.description,
            "color": family.color,
            "icon": family.icon,
            "product_count": 0,
            "created_at": family.created_at.isoformat(),
            "updated_at": family.updated_at.isoformat(),
        }
    })

@productos_bp.patch("/families/<int:family_id>")
def update_family(family_id):
    """Update a family."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    family = Family.query.filter_by(id=family_id, workspace_id=workspace.id).first()
    
    if not family:
        return jsonify({"ok": False, "message": "Family not found."}), 404
    
    if "name" in data:
        family.name = data["name"]
    if "description" in data:
        family.description = data["description"]
    if "color" in data:
        family.color = data["color"]
    if "icon" in data:
        family.icon = data["icon"]
    
    db.session.commit()
    log_activity(workspace.id, "UPDATED", "FAMILY", family.id, family.name)
    
    return jsonify({"ok": True, "message": "Family updated."})

@productos_bp.delete("/families/<int:family_id>")
def delete_family(family_id):
    """Delete a family and all its products."""
    guard = require_login()
    if guard:
        return guard
    
    workspace = get_default_workspace()
    family = Family.query.filter_by(id=family_id, workspace_id=workspace.id).first()
    
    if not family:
        return jsonify({"ok": False, "message": "Family not found."}), 404
    
    db.session.delete(family)
    db.session.commit()
    log_activity(workspace.id, "DELETED", "FAMILY", family.id, family.name)
    
    return jsonify({"ok": True, "message": f"Family '{family.name}' deleted."})

# ---- Products ----
@productos_bp.get("/products")
def list_products():
    """List all products, optionally filtered by family."""
    family_id = request.args.get("family_id", type=int)
    workspace = get_default_workspace()
    
    query = Product.query.filter_by(workspace_id=workspace.id)
    if family_id:
        query = query.filter_by(family_id=family_id)
    
    products = query.order_by(Product.updated_at.desc()).all()
    return jsonify({
        "products": [
            {
                "id": p.id,
                "name": p.name,
                "slug": p.slug,
                "description": p.description,
                "icon": p.icon,
                "family_id": p.family_id,
                "lifecycle": p.lifecycle,
                "status": p.status,
                "health_score": 65,
                "created_at": p.created_at.isoformat(),
                "updated_at": p.updated_at.isoformat(),
            } for p in products
        ]
    })

@productos_bp.get("/products/<int:product_id>")
def get_product(product_id):
    """Get detailed product information."""
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    return jsonify({
        "product": {
            "id": product.id,
            "name": product.name,
            "slug": product.slug,
            "description": product.description,
            "icon": product.icon,
            "family_id": product.family_id,
            "lifecycle": product.lifecycle,
            "status": product.status,
            "target_audience": product.target_audience,
            "key_features": product.key_features,
            "health_score": 65,
            "milestones": len(product.milestones),
            "tasks": len(product.tasks),
            "context_blocks": len(product.context_blocks),
            "sessions": len(product.sessions),
            "decisions": len(product.decisions),
            "created_at": product.created_at.isoformat(),
            "updated_at": product.updated_at.isoformat(),
        }
    })

@productos_bp.post("/products")
def create_product():
    """Create a new product."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    
    name = (data.get("name") or "").strip()
    family_id = data.get("family_id")
    
    if not name:
        return jsonify({"ok": False, "message": "Product name is required."}), 400
    if not family_id:
        return jsonify({"ok": False, "message": "Family selection is required."}), 400
    
    family = Family.query.filter_by(id=family_id, workspace_id=workspace.id).first()
    if not family:
        return jsonify({"ok": False, "message": "Family not found."}), 404
    
    from slugify import slugify
    slug = slugify(name, separator="-")
    
    if Product.query.filter_by(workspace_id=workspace.id, slug=slug).first():
        return jsonify({"ok": False, "message": "Product with this name already exists."}), 409
    
    product = Product(
        workspace_id=workspace.id,
        family_id=family_id,
        owner_id=g.current_user.id,
        name=name,
        slug=slug,
        description=data.get("description", ""),
        icon=data.get("icon", "box"),
        lifecycle="IDEA",
        status="ACTIVE"
    )
    
    db.session.add(product)
    db.session.commit()
    
    log_activity(workspace.id, "CREATED", "PRODUCT", product.id, product.name)
    
    return jsonify({
        "ok": True,
        "product": {
            "id": product.id,
            "name": product.name,
            "slug": product.slug,
            "description": product.description,
            "icon": product.icon,
            "family_id": product.family_id,
            "lifecycle": product.lifecycle,
            "status": product.status,
            "health_score": 0,
            "created_at": product.created_at.isoformat(),
            "updated_at": product.updated_at.isoformat(),
        }
    })

@productos_bp.patch("/products/<int:product_id>")
def update_product(product_id):
    """Update product metadata."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    if "name" in data:
        product.name = data["name"]
    if "description" in data:
        product.description = data["description"]
    if "lifecycle" in data:
        product.lifecycle = data["lifecycle"]
    if "status" in data:
        product.status = data["status"]
    
    db.session.commit()
    log_activity(workspace.id, "UPDATED", "PRODUCT", product.id, product.name)
    
    return jsonify({"ok": True, "message": "Product updated."})

@productos_bp.delete("/products/<int:product_id>")
def delete_product(product_id):
    """Delete a product."""
    guard = require_login()
    if guard:
        return guard
    
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    product_name = product.name
    db.session.delete(product)
    db.session.commit()
    log_activity(workspace.id, "DELETED", "PRODUCT", product.id, product_name)
    
    return jsonify({"ok": True, "message": f"Product '{product_name}' deleted."})

# ---- Context Blocks ----
@productos_bp.get("/products/<int:product_id>/context-blocks")
def list_context_blocks(product_id):
    """List context blocks for a product."""
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    blocks = ContextBlock.query.filter_by(product_id=product_id).order_by(ContextBlock.priority).all()
    return jsonify({
        "context_blocks": [
            {
                "id": b.id,
                "title": b.title,
                "content": b.content,
                "category": b.category,
                "priority": b.priority,
                "is_public": b.is_public,
                "created_at": b.created_at.isoformat(),
            } for b in blocks
        ]
    })

@productos_bp.post("/products/<int:product_id>/context-blocks")
def create_context_block(product_id):
    """Create a context block."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    title = (data.get("title") or "").strip()
    content = (data.get("content") or "").strip()
    
    if not title or not content:
        return jsonify({"ok": False, "message": "Title and content are required."}), 400
    
    block = ContextBlock(
        product_id=product_id,
        title=title,
        content=content,
        category=data.get("category", "OTHER"),
        priority=data.get("priority", 1),
        is_public=data.get("is_public", True)
    )
    
    db.session.add(block)
    db.session.commit()
    
    return jsonify({"ok": True, "message": "Context block created."})

# ---- Sessions ----
@productos_bp.get("/products/<int:product_id>/sessions")
def list_sessions(product_id):
    """List work sessions for a product."""
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    sessions = Session.query.filter_by(product_id=product_id).order_by(Session.created_at.desc()).all()
    return jsonify({
        "sessions": [
            {
                "id": s.id,
                "tool": s.tool,
                "goal": s.goal,
                "summary": s.summary,
                "outcome": s.outcome,
                "next_steps": s.next_steps,
                "created_at": s.created_at.isoformat(),
            } for s in sessions
        ]
    })

@productos_bp.post("/products/<int:product_id>/sessions")
def create_session(product_id):
    """Create a work session record."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    goal = (data.get("goal") or "").strip()
    summary = (data.get("summary") or "").strip()
    
    if not goal or not summary:
        return jsonify({"ok": False, "message": "Goal and summary are required."}), 400
    
    session = Session(
        product_id=product_id,
        tool=data.get("tool", "MANUAL"),
        goal=goal,
        summary=summary,
        outcome=data.get("outcome", ""),
        next_steps=data.get("next_steps", ""),
    )
    
    db.session.add(session)
    db.session.commit()
    
    return jsonify({"ok": True, "message": "Session created."})

# ---- Milestones ----
@productos_bp.post("/products/<int:product_id>/milestones")
def create_milestone(product_id):
    """Create a milestone."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"ok": False, "message": "Milestone name is required."}), 400
    
    milestone = Milestone(
        product_id=product_id,
        name=name,
        description=data.get("description"),
        priority=data.get("priority", "MEDIUM")
    )
    
    db.session.add(milestone)
    db.session.commit()
    
    return jsonify({"ok": True, "message": "Milestone created."})

# ---- Tasks ----
@productos_bp.post("/products/<int:product_id>/tasks")
def create_task(product_id):
    """Create a task."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"ok": False, "message": "Task name is required."}), 400
    
    task = Task(
        product_id=product_id,
        milestone_id=data.get("milestone_id"),
        name=name,
        description=data.get("description"),
        priority=data.get("priority", "MEDIUM")
    )
    
    db.session.add(task)
    db.session.commit()
    
    return jsonify({"ok": True, "message": "Task created."})

@productos_bp.patch("/tasks/<int:task_id>")
def update_task(task_id):
    """Update a task."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    task = Task.query.get_or_404(task_id)
    
    if "status" in data:
        task.status = data["status"]
        if data["status"] == "COMPLETED":
            task.completed_at = datetime.utcnow()
    
    if "name" in data:
        task.name = data["name"]
    if "description" in data:
        task.description = data["description"]
    
    db.session.commit()
    
    return jsonify({"ok": True, "message": "Task updated."})

# ---- Decisions ----
@productos_bp.post("/products/<int:product_id>/decisions")
def create_decision(product_id):
    """Create a decision record."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    title = (data.get("title") or "").strip()
    decision = (data.get("decision") or "").strip()
    
    if not title or not decision:
        return jsonify({"ok": False, "message": "Title and decision are required."}), 400
    
    decision_obj = Decision(
        product_id=product_id,
        title=title,
        decision=decision,
        rationale=data.get("rationale"),
    )
    
    db.session.add(decision_obj)
    db.session.commit()
    
    return jsonify({"ok": True, "message": "Decision created."})

# ---- Notes ----
@productos_bp.post("/products/<int:product_id>/notes")
def create_product_note(product_id):
    """Create a product note."""
    guard = require_login()
    if guard:
        return guard
    
    data = request.get_json(silent=True) or {}
    workspace = get_default_workspace()
    product = Product.query.filter_by(id=product_id, workspace_id=workspace.id).first()
    
    if not product:
        return jsonify({"ok": False, "message": "Product not found."}), 404
    
    title = (data.get("title") or "").strip()
    content = (data.get("content") or "").strip()
    
    if not title or not content:
        return jsonify({"ok": False, "message": "Title and content are required."}), 400
    
    note = ProductNote(
        product_id=product_id,
        title=title,
        content=content,
        pinned=data.get("pinned", False)
    )
    
    db.session.add(note)
    db.session.commit()
    
    return jsonify({"ok": True, "message": "Note created."})
