"""ProductOS API endpoints"""

from flask import Blueprint, jsonify, request, g
from datetime import datetime
from .db import db
from .models import (
    Family, Product, ContextBlock, Session, Decision, Milestone, Task,
    Prompt, ProductKnowledge, ProductNote, GlobalNote, Activity, Workspace, User
)

productos_bp = Blueprint("productos", __name__, url_prefix="/api/productos")

def require_login():
    if not g.current_user:
        return jsonify({"ok": False, "message": "Login required."}), 401
    return None

def get_default_workspace():
    """Get or create default workspace."""
    workspace = Workspace.query.filter_by(name="Default").first()
    if not workspace:
        workspace = Workspace(name="Default")
        db.session.add(workspace)
        db.session.commit()
    return workspace

def log_activity(workspace_id, action, entity_type, entity_id, entity_name):
    """Log activity for audit trail."""
    activity = Activity(
        workspace_id=workspace_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        entity_name=entity_name
    )
    db.session.add(activity)
    db.session.commit()

# ---- Families ----
@productos_bp.get("/families")
def list_families():
    """List all families in default workspace."""
    workspace = get_default_workspace()
    families = Family.query.filter_by(workspace_id=workspace.id).order_by(Family.display_order).all()
    return jsonify({
        "families": [
            {
                "id": f.id,
                "name": f.name,
                "description": f.description,
                "color": f.color,
                "icon": f.icon,
                "product_count": len(f.products),
                "created_at": f.created_at.isoformat(),
                "updated_at": f.updated_at.isoformat(),
            } for f in families
        ]
    })
