from pathlib import Path

from flask import Flask, jsonify

from .db import db
from flask_migrate import Migrate
from .schema import ensure_schema
from .utils.world_cup_data import seed_matches_if_empty

migrate = Migrate()


def create_app():
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object("config.Config")

    instance_path = Path(app.root_path).parent / "instance"
    instance_path.mkdir(exist_ok=True)

    db.init_app(app)
    migrate.init_app(app, db)

    from .api import api_bp
    from .productos_api import productos_bp

    app.register_blueprint(api_bp)
    app.register_blueprint(productos_bp)

    @app.get("/health")
    def health():
        return "ok"

    @app.get("/")
    def root():
        return jsonify({"service": app.config["APP_TITLE"], "api": "/api"})

    with app.app_context():
        db.create_all()
        ensure_schema()
        
        # Only seed if tables exist and have correct schema
        try:
            seed_matches_if_empty()
        except Exception as e:
            print(f"⚠️  Skipping seed: {e}")
        
        # Create default workspace for ProductOS
        try:
            from .productos_api import get_default_workspace
            get_default_workspace()
        except Exception as e:
            print(f"⚠️  Skipping workspace creation: {e}")

    return app
