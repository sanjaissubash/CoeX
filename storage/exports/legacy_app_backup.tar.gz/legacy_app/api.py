"""JSON API consumed by the Next.js frontend.

The whole app used to render Jinja templates; it is now an API-only Flask
service. Authentication stays exactly as before: a username-only session
cookie. Because the Next.js dev server proxies ``/api`` to Flask, the browser
sees a single origin and the session cookie just works.
"""

from datetime import datetime, timedelta, timezone

from flask import Blueprint, current_app, g, jsonify, request, session
from sqlalchemy.exc import IntegrityError, OperationalError

from .db import db
from .models import Match, Prediction, User
from .utils.football_data import (
    FootballDataSyncError,
    fetch_world_cup_scorers,
    fetch_world_cup_squad_players,
    sync_world_cup_matches,
)
from .utils.potm_data import PotmSourceError, fetch_potm_for_matches
from .utils.scoring import build_leaderboard
from .utils.world_cup_data import (
    MVP_PLAYER_OPTIONS,
    QUALIFIED_TEAMS,
    SEEDED_MATCHES,
    TEAM_LOOKUP,
    seed_matches_if_empty,
    team_choices,
)


api_bp = Blueprint("api", __name__, url_prefix="/api")

DEFAULT_FLAG = "\U0001F3F3\uFE0F"  # 🏳️

# All kickoff times are stored as naive UTC (football-data.org is UTC). India
# has no DST, so a fixed +05:30 offset is exact.
IST = timezone(timedelta(hours=5, minutes=30))
VISIBLE_BEFORE = timedelta(hours=24)   # fixtures appear 24h before kickoff
LOCK_AFTER = timedelta(minutes=15)    # picks close 15 min after kickoff


def _utc_now():
    return datetime.utcnow()


def _utc_iso(naive_utc):
    """ISO 8601 instant (UTC) so the browser can compute countdowns correctly."""
    return naive_utc.replace(tzinfo=timezone.utc).isoformat()


def _ist_string(naive_utc):
    aware = naive_utc.replace(tzinfo=timezone.utc).astimezone(IST)
    return aware.strftime("%d %b %Y · %I:%M %p IST")


_last_football_data_sync = None
_FOOTBALL_DATA_SYNC_THROTTLE_SECONDS = 300
_last_potm_sync = None
_POTM_SYNC_THROTTLE_SECONDS = 300


def _auto_sync_football_data():
    global _last_football_data_sync
    if not current_app.config["FOOTBALL_DATA_API_KEY"]:
        return

    now = datetime.utcnow()
    if _last_football_data_sync and (now - _last_football_data_sync).total_seconds() < _FOOTBALL_DATA_SYNC_THROTTLE_SECONDS:
        return

    try:
        sync_world_cup_matches(
            current_app.config["FOOTBALL_DATA_BASE_URL"],
            current_app.config["FOOTBALL_DATA_API_KEY"],
            current_app.config["FOOTBALL_DATA_COMPETITION_CODE"],
        )
    except FootballDataSyncError:
        pass
    finally:
        _last_football_data_sync = now

    _auto_sync_potm_data()


def _auto_sync_potm_data():
    global _last_potm_sync
    provider = (current_app.config.get("POTM_PROVIDER") or "manual").strip().lower()
    if provider == "manual":
        return

    if not current_app.config.get("POTM_HTTP_ENDPOINT"):
        return

    now = datetime.utcnow()
    throttle_seconds = current_app.config.get("POTM_SYNC_THROTTLE_SECONDS", 300)
    if _last_potm_sync and (now - _last_potm_sync).total_seconds() < throttle_seconds:
        return

    match_ids = [
        match.api_match_id
        for match in Match.query.filter(Match.api_match_id != None, Match.winner != None, Match.potm_winner == None).all()
        if match.api_match_id
    ]

    if not match_ids:
        _last_potm_sync = now
        return

    try:
        potm_mapping = fetch_potm_for_matches(
            provider,
            current_app.config.get("POTM_HTTP_ENDPOINT"),
            current_app.config.get("POTM_HTTP_API_KEY"),
            current_app.config.get("FOOTBALL_DATA_COMPETITION_CODE"),
            match_ids,
        )
        if potm_mapping:
            for match in Match.query.filter(Match.api_match_id.in_(potm_mapping.keys()), Match.potm_winner == None).all():
                potm_name = potm_mapping.get(match.api_match_id)
                if potm_name:
                    match.potm_winner = potm_name
            db.session.commit()
